package com.tallerwebi.dominio.servicios;

import com.tallerwebi.dominio.entidades.Usuario;
import com.tallerwebi.dominio.excepcion.CredencialesInvalidasException;
import com.tallerwebi.dominio.servicios.interfaces.ServicioLogin;
import com.tallerwebi.infraestructura.RepositorioUsuario;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("servicioLogin")
@Transactional
public class ServicioLoginImpl implements ServicioLogin {

    private static final String ERROR_CREDENCIALES = "Usuario o clave incorrecta";

    private final RepositorioUsuario repositorioUsuario;

    @Autowired
    public ServicioLoginImpl(RepositorioUsuario repositorioUsuario) {
        this.repositorioUsuario = repositorioUsuario;
    }

    @Override
    public Usuario consultarUsuario(String email) {
        return repositorioUsuario.buscarUsuarioPorEmail(email);
    }

    @Override
    public Usuario autenticar(String credencial, String password)
        throws CredencialesInvalidasException {
        validarParametros(credencial, password);

        Usuario usuario = repositorioUsuario.buscarUsuarioPorCredencial(credencial);

        if (usuario == null) {
            throw new CredencialesInvalidasException(ERROR_CREDENCIALES);
        }

        validarPassword(password, usuario.getPassword());

        return usuario;
    }

    private void validarParametros(String credencial, String password)
        throws CredencialesInvalidasException {
        if (esInvalido(credencial) || esInvalido(password)) {
            throw new CredencialesInvalidasException(ERROR_CREDENCIALES);
        }
    }

    private Boolean esInvalido(String dato) {
        return dato == null || dato.isBlank();
    }

    private void validarPassword(String passwordIngresada, String passwordAlmacenada)
        throws CredencialesInvalidasException {
        String passwordHasheada = HashContrasenia.generar(passwordIngresada);
        if (!passwordHasheada.equals(passwordAlmacenada)) {
            throw new CredencialesInvalidasException(ERROR_CREDENCIALES);
        }
    }


    @Override
    public Usuario buscarPorId(Long id) {
        return this.repositorioUsuario.buscarUsuarioPorId(id);
    }

    @Override
    public void actualizarAvatar(Long idUsuario, String nuevoAvatar) {
        Usuario usuario = this.repositorioUsuario.buscarUsuarioPorId(idUsuario);
        if (usuario != null) {
            usuario.setAvatar(nuevoAvatar);
            this.repositorioUsuario.modificar(usuario);
        }
    }
}
