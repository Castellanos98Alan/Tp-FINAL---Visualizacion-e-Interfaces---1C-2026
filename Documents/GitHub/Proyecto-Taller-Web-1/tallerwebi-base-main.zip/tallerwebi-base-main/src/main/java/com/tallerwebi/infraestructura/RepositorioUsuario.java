package com.tallerwebi.infraestructura;

import com.tallerwebi.dominio.entidades.Usuario;

//@SuppressWarnings("PMD.ImplicitFunctionalInterface")
public interface RepositorioUsuario {
  Usuario buscarUsuarioPorEmail(String email);
  void guardar(Usuario usuario);
  void modificar(Usuario usuario);
  Usuario buscarUsuarioPorUsername(String nick);
  Boolean verificarEmailExistente(String email);
  Boolean verificarUsernameExistente(String username);
  Usuario buscarUsuarioPorId(Long id);
  Usuario buscarUsuarioPorCredencial(String credencial);

}
