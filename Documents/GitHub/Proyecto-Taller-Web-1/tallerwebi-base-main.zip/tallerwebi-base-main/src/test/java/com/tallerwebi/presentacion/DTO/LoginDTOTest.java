package com.tallerwebi.presentacion.DTO;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import org.junit.jupiter.api.Test;

import com.tallerwebi.presentacion.DTO.LoginDTO;

public class LoginDTOTest {

  @Test
  public void dadoQueExisteUnFormularioDeLoginDeberiaDevolverUnLoginConDatosCargados() {
    LoginDTO login = new LoginDTO();

    login.setCredencial("juli@gmail.com");
    login.setPassword("03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4");

    assertThat(login.getCredencial(), is("juli@gmail.com"));
    assertThat(
      login.getPassword(),
      is("03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4")
    );
  }
}
